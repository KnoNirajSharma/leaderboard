package com.knoldus.leader_board

final case class ContributionCount(monthly: Int, allTime: Int)
