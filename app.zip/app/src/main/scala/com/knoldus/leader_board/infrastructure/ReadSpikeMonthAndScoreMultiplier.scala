package com.knoldus.leader_board.infrastructure

trait ReadSpikeMonthAndScoreMultiplier {
  def readContributionScoreMultiplierAndSpikeMonth: ContributionPointsWithMultiplier
}
