-- knoldus_leaderboard schema

-- !Ups

update knolder set wordpress_id='nishchal26' where wordpress_id='Nishchal26';
update knolder set wordpress_id='yatharthsharma4251' where wordpress_id='Yatharthsharma4251';
​
update blog set wordpress_id='nishchal26' where wordpress_id='Nishchal26';
update blog set wordpress_id='yatharthsharma4251' where wordpress_id='Yatharthsharma4251';
